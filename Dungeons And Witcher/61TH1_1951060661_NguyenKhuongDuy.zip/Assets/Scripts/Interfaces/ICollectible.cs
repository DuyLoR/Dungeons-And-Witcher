public interface ICollectible
{
    public void Collect();
}
