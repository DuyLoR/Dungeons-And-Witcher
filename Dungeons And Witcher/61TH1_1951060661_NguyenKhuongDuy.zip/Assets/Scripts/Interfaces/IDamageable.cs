public interface IDamageable
{
    public void Damage(int amount);
}
